//============================================================================
// Name        : Portfolio.cpp
// Author      : Lucy Mills
// Class       : CSC450
// Assignment  : Create two threads to count up to 20 then down to 0
// Description : CSC450 Portfolio Project
//============================================================================
#include <iostream>
#include <thread>
using namespace std;

//create the global counting variable 
int c = 0;

// create void function for counting up
// use '::' notation to access the global counting variable
void countUp() {
	cout << "Started counting up." << endl;
	while (::c < 20) {
		::c++;
		// print value while counting
		cout << ::c << endl; 
	}
}
// create void function for counting down
void countDown() {
	cout << "Started counting down." << endl;
	while (::c >= 0) {
		// print value while counting
		cout << ::c << endl; 
		::c--; 
	}
}

int main() {
	// create the first thread
	thread thread1(countUp);
	// join thread to main
	thread1.join(); 
	// create the second thread
	thread thread2(countDown); 
	// join other thread to main
	thread2.join(); 
	return 0;
}