package com.deitel.welcome;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.support.annotation.Nullable;
import android.widget.Toast;

public class ActivityTwo extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);
        //send toast message
        Toast.makeText(ActivityTwo.this, "Click the button to be redirected to link.", Toast.LENGTH_SHORT).show();
        //setup link connection for button in the app
        final Button mlink = (Button) findViewById(R.id.missionLinkButton);
        // setup a listener for the button
        mlink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mlink.setMovementMethod(LinkMovementMethod.getInstance());
            }
        });
    }
}
