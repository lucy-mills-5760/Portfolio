package com.deitel.welcome;


import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private MainActivity context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;

        //send toast message
        Toast.makeText(MainActivity.this, "Welcome users", Toast.LENGTH_SHORT).show();

        //setup buttons for the other activities
        final Button mButton = (Button) findViewById(R.id.missionButton);
        final Button pButton = (Button) findViewById(R.id.programButton);
        final Button sButton = (Button) findViewById(R.id.sponsorButton);
        // setup a listener for the mission button
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchActivityTwo(v);
            }
        });
        // setup a listener for the programming button
        pButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchActivityThree(v);
            }
        });
        // setup a listener for the sponsorship button
        sButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchActivityFour(v);
            }
        });
    }

    public static void launchActivityTwo(View view) {
        Context context = view.getContext();
        context.startActivity(new Intent(context, ActivityTwo.class));
    }
    public static void launchActivityThree(View view) {
        Context context = view.getContext();
        context.startActivity(new Intent(context, ActivityThree.class));
    }
    public static void launchActivityFour(View view) {
        Context context = view.getContext();
        context.startActivity(new Intent(context, ActivityFour.class));
    }
}