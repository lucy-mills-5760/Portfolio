package com.deitel.welcome;
import android.app.Activity;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.support.annotation.Nullable;
import android.widget.Toast;

public class ActivityThree extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //send toast message
        Toast.makeText(ActivityThree.this, "Click the button to be redirected to link.", Toast.LENGTH_SHORT).show();
        setContentView(R.layout.activity_three);
        //setup link connection for button in the app
        final Button plink = (Button) findViewById(R.id.programLinkButton);
        // setup a listener for the button
        plink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                plink.setMovementMethod(LinkMovementMethod.getInstance());
            }
        });
    }
}