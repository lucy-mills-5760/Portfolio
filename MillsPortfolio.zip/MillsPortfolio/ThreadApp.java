//============================================================================
// Name        : ThreadApp
// Author      : Lucy Mills
// Class       : CSC450
// Assignment  : Create two threads to count up to 20 then down to 0
// Description : CSC450 Portfolio Project
//============================================================================

// must extend thread class to use it
class ThreadApp extends Thread {
    // have the first thread run in the main function
    public static void main(String[] args) {
        Thread countUp = Thread.currentThread();
        countUp.setPriority(MAX_PRIORITY);
        for (int i = 1; i <= 20; i++) {
          System.out.println("Ascending counter: " + i);
        }
        SecondThread countDown = new SecondThread();
        countDown.start();
    }
}
// and the next thread runs in a seperate thread class 
class SecondThread extends Thread {
@Override
public void run() {
    for (int j = 20; j >= 1; j--) {
      System.out.println("Descending counter: " + j);
    }
}
}